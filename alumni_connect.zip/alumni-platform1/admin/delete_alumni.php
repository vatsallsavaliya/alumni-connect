<?php
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) { die("DB Error"); }

$id = intval($_GET['id']); // because we pass ?id= in JS

$sql = "DELETE FROM users WHERE id=$id AND role='alumni'";
if ($conn->query($sql)) {
    echo "Alumni deleted successfully!";
} else {
    echo "Error: " . $conn->error;
}
?>
