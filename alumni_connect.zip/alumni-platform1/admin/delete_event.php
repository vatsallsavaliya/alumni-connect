<?php
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) { die("DB Error"); }

$id = intval($_GET['id']);

$sql = "DELETE FROM events WHERE id=$id";
if ($conn->query($sql)) {
    echo "Event deleted successfully!";
} else {
    echo "Error: " . $conn->error;
}
?>
