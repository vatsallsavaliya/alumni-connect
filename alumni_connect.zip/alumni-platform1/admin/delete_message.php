<?php
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) { die("DB Error"); }

$id = intval($_GET['id']);

$sql = "DELETE FROM contact_messages WHERE id=$id";
if ($conn->query($sql)) {
    echo "Message deleted successfully!";
} else {
    echo "Error: " . $conn->error;
}
?>
