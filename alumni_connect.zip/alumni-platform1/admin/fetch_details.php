<?php
$type = $_GET['type'] ?? '';
$id   = intval($_GET['id']);
$mode = $_GET['mode'] ?? 'view';

if ($type == "alumni") {
    $res = $conn->query("SELECT * FROM users WHERE id=$id AND role='alumni'");
    $row = $res->fetch_assoc();

    if ($mode == "edit") {
        echo "<h2>Edit Alumni</h2>
              <form method='POST' action='update_alumni.php'>
                <input type='hidden' name='id' value='{$row['id']}'>
                <label>Name: <input type='text' name='name' value='{$row['name']}'></label><br>
                <label>Email: <input type='email' name='email' value='{$row['email']}'></label><br>
                <label>Phone: <input type='text' name='phone' value='{$row['phone']}'></label><br>
                <label>Department: <input type='text' name='department' value='{$row['department']}'></label><br>
                <label>Graduation Year: <input type='number' name='graduation_year' value='{$row['graduation_year']}'></label><br>
                <label>Bio:<br><textarea name='bio'>{$row['bio']}</textarea></label><br>
                <button type='submit'>Save</button>
              </form>";
    } else {
        echo "<h2>{$row['name']}</h2>
              <p><strong>Email:</strong> {$row['email']}</p>
              <p><strong>Phone:</strong> {$row['phone']}</p>
              <p><strong>Department:</strong> {$row['department']}</p>
              <p><strong>Graduation:</strong> {$row['graduation_year']}</p>
              <p><strong>Bio:</strong> {$row['bio']}</p>";
    }
}
