<?php
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) { die("DB Error"); }

$id   = intval($_POST['id']);
$name = $conn->real_escape_string($_POST['name']);
$email = $conn->real_escape_string($_POST['email']);
$phone = $conn->real_escape_string($_POST['phone']);
$dept = $conn->real_escape_string($_POST['department']);
$year = intval($_POST['graduation_year']);
$bio  = $conn->real_escape_string($_POST['bio']);

$sql = "UPDATE users SET 
          name='$name',
          email='$email',
          phone='$phone',
          department='$dept',
          graduation_year='$year',
          bio='$bio'
        WHERE id=$id AND role='alumni'";

if ($conn->query($sql)) {
    echo "Alumni updated successfully!";
} else {
    echo "Error: " . $conn->error;
}
?>
