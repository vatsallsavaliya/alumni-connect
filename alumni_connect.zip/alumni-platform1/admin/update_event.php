<?php
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) { 
    die("DB Error: " . $conn->connect_error);
}

$id          = intval($_POST['id']);
$title       = $_POST['title'];
$description = $_POST['description'];
$location    = $_POST['location'];
$start_date  = $_POST['start_date'];
$end_date    = $_POST['end_date'];

if ($id > 0) {
    // ✅ UPDATE existing event
    $stmt = $conn->prepare("UPDATE events SET title=?, description=?, location=?, start_date=?, end_date=? WHERE id=?");
    $stmt->bind_param("sssssi", $title, $description, $location, $start_date, $end_date, $id);
    if ($stmt->execute()) {
        echo "Event updated successfully";
    } else {
        echo "Error updating event: " . $conn->error;
    }
} else {
    // ✅ INSERT new event
    $stmt = $conn->prepare("INSERT INTO events (title, description, location, start_date, end_date, created_at) VALUES (?,?,?,?,?, NOW())");
    $stmt->bind_param("sssss", $title, $description, $location, $start_date, $end_date);
    if ($stmt->execute()) {
        echo "Event added successfully";
    } else {
        echo "Error adding event: " . $conn->error;
    }
}
?>
