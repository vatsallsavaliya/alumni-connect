<?php
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) { die("DB Error"); }

$id    = intval($_POST['id']);
$name  = $conn->real_escape_string($_POST['full_name']);
$email = $conn->real_escape_string($_POST['email']);
$sub   = $conn->real_escape_string($_POST['subject']);
$msg   = $conn->real_escape_string($_POST['message']);

$sql = "UPDATE contact_messages SET 
            full_name='$name',
            email='$email',
            subject='$sub',
            message='$msg'
        WHERE id=$id";

if ($conn->query($sql)) {
    echo "Message updated successfully!";
} else {
    echo "Error: " . $conn->error;
}
?>
