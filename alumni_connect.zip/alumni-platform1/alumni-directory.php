
<?php
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) {
    die("DB Connection failed: " . $conn->connect_error);
}

$perPage   = 6;
$page      = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start     = ($page - 1) * $perPage;

$search    = isset($_GET['search']) ? $_GET['search'] : '';
$year      = isset($_GET['year']) ? $_GET['year'] : '';
$degree    = isset($_GET['degree']) ? $_GET['degree'] : '';
$industry  = isset($_GET['industry']) ? $_GET['industry'] : '';

$where = "WHERE status='approved'";
if ($search !== '') {
    $s = $conn->real_escape_string($search);
    $where .= " AND (name LIKE '%$s%' OR company LIKE '%$s%')";
}
if ($year !== '')    $where .= " AND class_of_year = '$year'";
if ($degree !== '')  $where .= " AND degree = '$degree'";
if ($industry !== '')$where .= " AND position LIKE '%$industry%'";

$countSQL  = $conn->query("SELECT COUNT(*) as total FROM alumni_directory $where");
$totalRows = $countSQL->fetch_assoc()['total'];
$totalPages= ceil($totalRows / $perPage);

$sql  = "SELECT * FROM alumni_directory $where LIMIT $start,$perPage";
$data = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Alumni Directory - GEC Alumni Association</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/animations.css" rel="stylesheet">
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php"><img src="images/Rajkot__1_-removebg-preview.png" height="60"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                <li class="nav-item"><a class="nav-link active" href="alumni-directory.php">Alumni</a></li>
                <li class="nav-item"><a class="nav-link" href="events.php">Events</a></li>
                <li class="nav-item"><a class="nav-link" href="jobs.php">Jobs</a></li>
                <li class="nav-item"><a class="nav-link" href="success-stories.php">Success Stories</a></li>
                <li class="nav-item"><a class="nav-link" href="donate.php">Donate</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
                <li class="nav-item"><a class="nav-link btn-login" href="login.php">Login</a></li>
            </ul>
        </div>
    </div>
</nav>

<section class="py-5 mt-5">
    <div class="container">
        <div class="text-center mb-4">
            <h1 class="section-title">Alumni Directory</h1>
            <p class="lead">Connect with fellow graduates from Government Engineering College</p>
        </div>

        <!-- Search and Filters -->
        <form method="GET" class="card mb-4 shadow-sm">
          <div class="card-body">
            <div class="row g-2">
              <div class="col-md-4">
                <input type="text" class="form-control" name="search" value="<?=htmlspecialchars($search)?>" placeholder="Search by name, company, etc">
              </div>
              <div class="col-md-2">
                <select name="year" class="form-select">
                  <option value="">All Years</option>
                  <?php for($y=2000;$y<=2025;$y++): ?>
                  <option value="<?=$y?>" <?=$year==$y?'selected':''?>><?=$y?></option>
                  <?php endfor;?>
                </select>
              </div>
              <div class="col-md-2">
                <select name="degree" class="form-select">
                  <option value="">All Degrees</option>
                  <option value="B.Tech" <?=$degree=='B.Tech'?'selected':''?>>B.Tech</option>
                  <option value="M.Tech" <?=$degree=='M.Tech'?'selected':''?>>M.Tech</option>
                  <option value="PhD" <?=$degree=='PhD'?'selected':''?>>PhD</option>
                </select>
              </div>
              <div class="col-md-2">
                <select name="industry" class="form-select">
                  <option value="">All Industries</option>
                  <option value="Scientist" <?=$industry=='Scientist'?'selected':''?>>Scientist</option>
                  <option value="Engineer" <?=$industry=='Engineer'?'selected':''?>>Engineer</option>
                  <option value="Developer" <?=$industry=='Developer'?'selected':''?>>Developer</option>
                </select>
              </div>
              <div class="col-md-2">
                <button class="btn btn-primary w-100">Filter</button>
              </div>
            </div>
          </div>
        </form>

        <!-- Alumni listing -->
        <div class="row">
        <?php while($a = $data->fetch_assoc()): ?>
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="alumni-card hover-grow">
                    <div class="alumni-image text-center">
                        <img src="images/<?=$a['image']?>" alt="<?=$a['name']?>" class="img-fluid alumni-photo">
                    </div>
                    <div class="alumni-info">
                        <h3><?=$a['name']?></h3>
                        <p class="text-muted">Class of <?=$a['class_of_year']?>, <?=$a['branch']?></p>
                        <p><i class="fas fa-briefcase me-2"></i><?=$a['position']?> at <?=$a['company']?></p>
                        <p><i class="fas fa-map-marker-alt me-2"></i><?=$a['location']?></p>
                        <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#profile<?=$a['id']?>">View Profile</button>
                        <div class="social-links mt-2">
                            <a href="<?=$a['linkedin']?>" target="_blank"><i class="fab fa-linkedin"></i></a>
                            <a href="<?=$a['twitter']?>"  target="_blank"><i class="fab fa-twitter"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal -->
            <div class="modal fade" id="profile<?=$a['id']?>" tabindex="-1">
              <div class="modal-dialog modal-lg">
                <div class="modal-content">
                  <div class="modal-header bg-dark text-white">
                    <h5 class="modal-title"><?=$a['name']?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                  </div>
                  <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4"><img src="images/<?=$a['image']?>" class="img-fluid"></div>
                        <div class="col-md-8">
                            <p><strong>Year:</strong> <?=$a['class_of_year']?></p>
                            <p><strong>Branch:</strong> <?=$a['branch']?></p>
                            <p><strong>Position:</strong> <?=$a['position']?> at <?=$a['company']?></p>
                            <p><strong>Location:</strong> <?=$a['location']?></p>
                            <p><strong>Email:</strong> <?=$a['email']?></p>
                            <p><strong>Phone:</strong> <?=$a['phone']?></p>
                            <p><strong>Bio:</strong><br><?=$a['bio']?></p>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <nav aria-label="Page navigation">
          <ul class="pagination justify-content-center mt-4">
            <?php if($page>1): ?>
            <li class="page-item"><a class="page-link" href="?page=<?=$page-1?>&search=<?=$search?>&year=<?=$year?>&degree=<?=$degree?>&industry=<?=$industry?>">Previous</a></li>
            <?php endif; ?>
            <?php for($p=1;$p<=$totalPages;$p++): ?>
            <li class="page-item <?=$p==$page?'active':''?>"><a class="page-link" href="?page=<?=$p?>&search=<?=$search?>&year=<?=$year?>&degree=<?=$degree?>&industry=<?=$industry?>"><?=$p?></a></li>
            <?php endfor; ?>
            <?php if($page<$totalPages): ?>
            <li class="page-item"><a class="page-link" href="?page=<?=$page+1?>&search=<?=$search?>&year=<?=$year?>&degree=<?=$degree?>&industry=<?=$industry?>">Next</a></li>
            <?php endif; ?>
          </ul>
        </nav>
    </div>
</section>

<!-- Footer -->
<footer class="py-5 bg-dark text-white">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mb-4">
                <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
                <p>Connecting graduates of Government Engineering College across generations.</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 mb-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="alumni-directory.php">Alumni Directory</a></li>
                    <li><a href="events.php">Events</a></li>
                    <li><a href="jobs.php">Job Portal</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-6 mb-4">
                <h5>Resources</h5>
                <ul class="list-unstyled">
                    <li><a href="success-stories.php">Success Stories</a></li>
                    <li><a href="donate.php">Donate</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="col-lg-4 mb-4">
                <h5>Contact Information</h5>
                <ul class="list-unstyled">
                    <li><i class="fas fa-map-marker-alt me-2"></i> Government Engineering College, Rajkot, Gujarat</li>
                    <li><i class="fas fa-phone me-2"></i> +91 9876543210</li>
                    <li><i class="fas fa-envelope me-2"></i> alumni@gec.edu.in</li>
                </ul>
            </div>
        </div>
        <hr class="mt-4 mb-4">
        <div class="row">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-0">&copy; 2025 GEC Alumni Association. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <p class="mb-0"><a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
            </div>
        </div>
    </div>
</footer>

<!-- Back to Top Button -->
<a href="#" class="back-to-top animate-fade-in"><i class="fas fa-arrow-up"></i></a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/main.js"></script>
<script src="js/animations.js"></script>
</body>
</html>
