<?php
// --- Database Connection ---
$host = "localhost";
$dbname = "alumni_db";
$username = "root";   // change if needed
$password = "";       // change if needed

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Load PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/vendor/autoload.php'; // Adjust path if needed

$success = $error = "";

// --- Form Handling ---
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please provide a valid email address.";
    } else {
        // Insert into database securely
        $stmt = $conn->prepare("INSERT INTO contact_messages (full_name, email, subject, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $subject, $message);

        if ($stmt->execute()) {
            // Prepare to send email using PHPMailer
            $mail = new PHPMailer(true);
            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';           // SMTP server (e.g., Gmail)
                $mail->SMTPAuth = true;
                $mail->Username = 'vatsalsavaliya024@gmail.com';  // Your email
                $mail->Password = 'jlsm excm ktee zpsq';     // App password (not your Gmail password)
                $mail->SMTPSecure = 'tls';                 // Encryption: 'tls' or 'ssl'
                $mail->Port = 587;                         // Port: 587 for TLS or 465 for SSL

                // Recipients
                $mail->setFrom('your-email@gmail.com', 'GEC Alumni Contact Form');
                $mail->addAddress('vatsalsavaliya024@gmail.com', 'GEC Alumni Admin');

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'New Contact Form Submission';
                $mail->Body = "
                    <p><strong>Name:</strong> " . htmlspecialchars($name) . "</p>
                    <p><strong>Email:</strong> " . htmlspecialchars($email) . "</p>
                    <p><strong>Subject:</strong> " . htmlspecialchars($subject) . "</p>
                    <p><strong>Message:</strong><br>" . nl2br(htmlspecialchars($message)) . "</p>
                ";

                $mail->AltBody = "Name: $name\nEmail: $email\nSubject: $subject\n\n$message";

                $mail->send();
                $success = "Thank you for your message! We will get back to you soon.";
            } catch (Exception $e) {
                $error = "Message saved in database, but email could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            $error = "Error saving message: " . $stmt->error;
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - GEC Alumni Association</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/animations.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="alumni-directory.php">Alumni</a></li>
                    <li class="nav-item"><a class="nav-link" href="events.php">Events</a></li>
                    <li class="nav-item"><a class="nav-link" href="jobs.php">Jobs</a></li>
                    <li class="nav-item"><a class="nav-link" href="success-stories.php">Success Stories</a></li>
                    <li class="nav-item"><a class="nav-link" href="donate.php">Donate</a></li>
                    <li class="nav-item"><a class="nav-link active" href="contact.php">Contact</a></li>
                    <li class="nav-item"><a class="nav-link btn-login" href="login.php">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Contact Hero Section -->
<section class="contact-hero py-5">
    <div class="container">
        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php elseif ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="row align-items-center">
            <div class="col-lg-6 animate-fade-in">
                <h1 class="display-4 fw-bold mb-4">Get in Touch</h1>
                <p class="lead mb-4">Have questions or feedback? Reach out to the GEC Alumni Association team.</p>
                <div class="d-flex align-items-center mb-3">
                    <div class="icon-box me-3"><i class="fas fa-envelope"></i></div>
                    <div>
                        <h5 class="mb-0">Email Us</h5>
                        <p class="mb-0">alumni@gec.edu</p>
                    </div>
                </div>

                <div class="d-flex align-items-center mb-3">
                    <div class="icon-box me-3"><i class="fas fa-phone"></i></div>
                    <div>
                        <h5 class="mb-0">Call Us</h5>
                        <p class="mb-0">+91 9876543210</p>  
                    </div>
                </div>

                <div class="d-flex align-items-center">
                    <div class="icon-box me-3"><i class="fas fa-map-marker-alt"></i></div>
                    <div>
                        <h5 class="mb-0">Visit Us</h5>
                        <p class="mb-0">Government Engineering College, Rajkot, Gujarat</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 animate-fade-in animate-delay-1">
                <div class="contact-card shadow-lg p-4 bg-white rounded">
                    <h3 class="mb-4">Send a Message</h3>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="name" class="form-label">Full Name</label>
                            <input type="text" class="form-control" name="name" id="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" id="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="subject" class="form-label">Subject</label>
                            <select class="form-select" name="subject" id="subject" required>
                                <option value="General Inquiry">General Inquiry</option>
                                <option value="Event Question">Event Question</option>
                                <option value="Donation Inquiry">Donation Inquiry</option>
                                <option value="Technical Support">Technical Support</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Message</label>
                            <textarea class="form-control" name="message" id="message" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Map Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Our Location</h2>
            <p class="lead">Visit the GEC campus or connect virtually</p>
        </div>
        <div class="row g-4">
            <div class="col-lg-6">
                <iframe src="https://www.google.com/maps/embed?pb=..." width="100%" height="400" style="border:0;" allowfullscreen></iframe>
            </div>
            <div class="col-lg-6">
                <div class="card h-100 shadow-sm">
                    <div class="card-body p-4">
                        <h4 class="mb-4">Office Hours</h4>
                        <ul class="list-unstyled">
                            <li class="mb-3 d-flex justify-content-between">
                                <span>Monday - Friday</span>
                                <span>9:00 AM - 5:00 PM</span>
                            </li>
                            <li class="mb-3 d-flex justify-content-between">
                                <span>Saturday</span>
                                <span>10:00 AM - 2:00 PM</span>
                            </li>
                            <li class="d-flex justify-content-between">
                                <span>Sunday</span>
                                <span>Closed</span>
                            </li>
                        </ul>
                        <hr>
                        <h4 class="mb-4">Connect With Us</h4>
                        <a href="#"><i class="fab fa-facebook-f me-3"></i></a>
                        <a href="#"><i class="fab fa-twitter me-3"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in me-3"></i></a>
                        <a href="#"><i class="fab fa-instagram me-3"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FAQ Section -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="section-title">Frequently Asked Questions</h2>
            <p class="lead">Quick answers to common questions</p>
        </div>
        <!-- Accordion -->
        <div class="accordion" id="faqAccordion">
            <div class="accordion-item mb-3">
                <h2 class="accordion-header" id="headingOne">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                        How do I update my alumni profile information?
                    </button>
                </h2>
                <div id="collapseOne" class="accordion-collapse collapse show">
                    <div class="accordion-body">
                        You can update your profile by logging into your account and visiting the "My Profile" section.
                    </div>
                </div>
            </div>
            <!-- More FAQ items here -->
        </div>
    </div>
</section>

    <!-- Footer -->
    <footer class="py-5 bg-dark text-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
                    <p>Connecting graduates of Government Engineering College across generations.</p>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="alumni-directory.php">Alumni Directory</a></li>
                        <li><a href="events.php">Events</a></li>
                        <li><a href="jobs.php">Job Portal</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5>Resources</h5>
                    <ul class="list-unstyled">
                        <li><a href="success-stories.php">Success Stories</a></li>
                        <li><a href="donate.php">Donate</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Contact Information</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt me-2"></i> Government Engineering College, Rajkot, Gujarat</li>
                        <li><i class="fas fa-phone me-2"></i> +91 9876543210</li>
                        <li><i class="fas fa-envelope me-2"></i> alumni@gec.edu.in</li>
                    </ul>
                </div>
            </div>
            <hr class="mt-4 mb-4">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">&copy; 2025 GEC Alumni Association. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <p class="mb-0"><a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <a href="#" class="back-to-top"><i class="fas fa-arrow-up"></i></a>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="js/main.js"></script>
    <script src="js/animations.js"></script>
    <!-- <script>
        // Contact form submission
        document.getElementById('contactForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const subject = document.getElementById('subject').value;
            const message = document.getElementById('message').value;
            
            // Simple validation
            if (!name || !email || !message) {
                alert('Please fill in all required fields.');
                return;
            }
            
            // In a real app, you would send this data to a server (e.g., via PHP)
            console.log('Form submitted:', { name, email, subject, message });
            
            // Show success message
            alert(`Thank you, ${name}! Your message has been sent. We'll respond to ${email} within 48 hours.`);
            
            // Reset form
            this.reset();
        });
    </script> -->
</body>
</html>
