<?php
// create_order.php
// Called by client to create a Razorpay order and return order details.

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

header('Content-Type: application/json');
require_once __DIR__ . '/razorpay_config.php';

// DB connection
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) {
    echo json_encode(['error' => 'DB connection failed']);
    exit;
}

// Read input JSON
$body = json_decode(file_get_contents('php://input'), true);

// DEBUG: log body for troubleshooting
file_put_contents("debug.log", print_r($body, true));

$name    = trim($body['name'] ?? '');
$email   = trim($body['email'] ?? '');
$phone   = trim($body['phone'] ?? '');
$purpose = trim($body['purpose'] ?? 'General Fund');

$amount = 0;
if (isset($body['amount'])) {
    $amount = floatval($body['amount']);  // ensure numeric
}

// Validation
if ($amount <= 0) {
    echo json_encode(['error' => 'Invalid amount', 'debug_body' => $body]);
    exit;
}
if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['error' => 'Invalid email', 'debug_body' => $body]);
    exit;
}
if (!$name) $name = 'Anonymous Donor';

// Convert to paise
$amount_paise = intval($amount * 100);

// Order payload for Razorpay
$orderData = [
    'amount'          => $amount_paise,  // ✅ correct variable
    'currency'        => 'INR',
    'receipt'         => 'don_' . time() . rand(1000, 9999),
    'payment_capture' => 1
];

// Create order via Razorpay Orders API
$api_url = "https://api.razorpay.com/v1/orders";
$ch = curl_init($api_url);
$payload = json_encode($orderData);

curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_USERPWD, $razorpayKeyId . ":" . $razorpayKeySecret);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Content-Length: ' . strlen($payload)
]);

$result = curl_exec($ch);
$http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_err = curl_error($ch);
curl_close($ch);

if ($result === false) {
    echo json_encode(['error' => 'Curl error: ' . $curl_err]);
    exit;
}

$resp = json_decode($result, true);
if ($http_status < 200 || $http_status >= 300 || !$resp) {
    echo json_encode(['error' => 'Razorpay order creation failed', 'details' => $resp]);
    exit;
}

$order_id = $resp['id'] ?? null;
if (!$order_id) {
    echo json_encode(['error' => 'No order id in response', 'details' => $resp]);
    exit;
}

// Save pending donation in DB
$stmt = $conn->prepare("INSERT INTO donations 
    (donor_name, donor_email, phone, amount, purpose, order_id, status) 
    VALUES (?, ?, ?, ?, ?, ?, ?)");

$status = 'created';
// 7 params = "sss d s s s" →  "sss dss s"
$stmt->bind_param(
    "sssdsss",
    $name,     // donor_name
    $email,    // donor_email
    $phone,    // phone
    $amount,   // amount (decimal)
    $purpose,  // purpose
    $order_id, // order_id
    $status    // status
);
$stmt->execute();
$stmt->close();
$conn->close();

// ✅ Return order info
echo json_encode([
    'success'      => true,
    'order'        => $resp,       // full Razorpay order details
    'razorpay_key' => $razorpayKeyId,
    'name'         => $name,
    'email'        => $email,
    'phone'        => $phone,
    'purpose'      => $purpose
]);
