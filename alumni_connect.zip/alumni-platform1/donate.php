<?php

// Database connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "alumni_db";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Initialize variables
$success = "";
$error = "";
$totalRaised = 0;
$totalDonors = 0;

// Fetch total raised amount and total donors
$sql = "SELECT 
    SUM(amount) AS total_raised, 
    COUNT(DISTINCT donor_email) AS total_donors 
FROM donations 
WHERE YEAR(created_at) = YEAR(CURDATE());
";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

$totalRaised = $row['total_raised'] ?? 0;
$totalDonors = $row['total_donors'] ?? 0;

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = trim($_POST['donorName']);
    $email   = trim($_POST['donorEmail']);
    $amount  = trim($_POST['Amount']);

    

    if (!empty($name) && !empty($email) && is_numeric($amount)) {
        $stmt = $conn->prepare("
        INSERT INTO donations 
            (donor_name, donor_email, phone, amount, purpose, status, payment_method, created_at, updated_at) 
        VALUES (?, ?, ?, ?, ?, 'success', 'razorpay', NOW(), NOW())
    ");
    $stmt->bind_param("sssds", $name, $email, $phone, $amount, $purpose);
    

        if ($stmt->execute()) {
            $success = "Thank you for your generous donation!";
            // Update totals after new donation
            // Fetch total raised amount and total donors (all time)
            $sql = "SELECT 
                        SUM(amount) AS total_raised, 
                        COUNT(DISTINCT donor_email) AS total_donors 
                    FROM donations";

            $result = $conn->query($sql);

            $totalRaised = 0;
            $totalDonors = 0;

            if ($result && $row = $result->fetch_assoc()) {
                $totalRaised = $row['total_raised'] ?? 0;
                $totalDonors = $row['total_donors'] ?? 0;
            }

        } else {
            $error = "Something went wrong. Please try again.";
        }

        $stmt->close();
    }
}
// --- Year-wise donations ---
$yearly = $conn->query("
    SELECT YEAR(created_at) AS year, SUM(amount) AS total
    FROM donations
    GROUP BY YEAR(created_at)
    ORDER BY year
");

// --- Top Donors ---
$topDonors = $conn->query("
    SELECT donor_name, donor_email, SUM(amount) AS total
    FROM donations
    GROUP BY donor_email
    ORDER BY total DESC
    LIMIT 10
");



$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>GEC Alumni Association</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="css/style.css">
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="js/donation.js" defer></script>
<script src="js/main.js" defer></script>
<script src="js/animations.js" defer></script>
</head>
<body>

    <!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                <li class="nav-item"><a class="nav-link" href="alumni-directory.php">Alumni</a></li>
                <li class="nav-item"><a class="nav-link" href="events.php">Events</a></li>
                <li class="nav-item"><a class="nav-link" href="jobs.php">Jobs</a></li>
                <li class="nav-item"><a class="nav-link" href="success-stories.php">Success Stories</a></li>
                <li class="nav-item"><a class="nav-link active" href="donate.php">Donate</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
                <li class="nav-item"><a class="nav-link btn-login" href="login.php">Login</a></li>
            </ul>
        </div>
    </div>
</nav>

    <!-- Donation Hero Section -->
<section class="donation-hero py-5 text-white" style="background:#80bcfd;">
    <div class="container">
        <?php if ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <?php elseif ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-4">Support Your Alma Mater</h1>
                <p class="lead mb-4">Your generous donations help us provide scholarships, improve facilities, and enhance the educational experience for current students.</p>
                <div class="d-flex align-items-center">
                    <div class="me-4">
                        <h3 class="mb-0">₹<?= number_format($totalRaised, 2) ?></h3>
                        <small>Total Donations</small>
                    </div>
                    <div class="me-4">
                        <h3 class="mb-0"><?= $totalDonors ?></h3>
                        <small>Total Donors</small>
                    </div>
                </div>

            </div>
            <div class="col-lg-6">
                <div class="card donation-card shadow">
                    <div class="card-header bg-primary text-white">
                        <h3 class="mb-0">Make a Donation</h3>
                    </div>
                    <div class="card-body">
                    <form id="donation-form" method="POST" action="">
                        <div class="mb-3">
                            <label for="donation-amount" class="form-label">Donation Amount (₹)</label>
                            <input type="number" class="form-control" name="donationAmount" id="donation-amount" placeholder="Enter amount in Rupees" min="1" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Donation Purpose</label>
                            <select class="form-select" name="donationPurpose" id="donation-purpose">
                                <option value="General Fund">General Fund (Greatest Need)</option>
                                <option value="Scholarships">Student Scholarships</option>
                                <option value="Facilities">Campus Facilities</option>
                                <option value="Research">Research Programs</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Your Name</label>
                            <input type="text" class="form-control" name="donorName" id="donor-name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="donorEmail" id="donor-email" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" name="donorPhone" id="donor-phone" required>
                        </div>

                        <div id="result" class="mt-2"></div>

                        <button id="donate-now" class="btn btn-primary btn-lg w-100" type="button">Donate with Razorpay</button>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="py-5 bg-light" id="donation-report">
    <div class="container">
        <h2 class="mb-4 text-center">📊 Donation Report</h2>

        <!-- Year-wise Donations -->
        <h4>Year-wise Contributions</h4>
        <table class="table table-bordered">
            <thead>
                <tr><th>Year</th><th>Total (₹)</th></tr>
            </thead>
            <tbody>
                <?php while ($row = $yearly->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['year']; ?></td>
                        <td><?php echo number_format($row['total'], 2); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <!-- Top Donors -->
        <h4 class="mt-5">🏆 Top 10 Donors</h4>
        <table class="table table-striped">
            <thead>
                <tr><th>Name</th><th>Email</th><th>Total Donated (₹)</th></tr>
            </thead>
            <tbody>
                <?php while ($row = $topDonors->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['donor_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['donor_email']); ?></td>
                        <td><?php echo number_format($row['total'], 2); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</section>


    <!-- Footer -->
    <footer class="py-5 bg-dark text-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
                    <p>Connecting graduates of Government Engineering College across generations.</p>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="alumni-directory.php">Alumni Directory</a></li>
                        <li><a href="events.php">Events</a></li>
                        <li><a href="jobs.php">Job Portal</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5>Resources</h5>
                    <ul class="list-unstyled">
                        <li><a href="success-stories.php">Success Stories</a></li>
                        <li><a href="donate.php">Donate</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Contact Information</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt me-2"></i> Government Engineering College, Rajkot, Gujarat</li>
                        <li><i class="fas fa-phone me-2"></i> +91 9876543210</li>
                        <li><i class="fas fa-envelope me-2"></i> alumni@gec.edu.in</li>
                    </ul>
                </div>
            </div>
            <hr class="mt-4 mb-4">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">&copy; 2025 GEC Alumni Association. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <p class="mb-0"><a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
<?php
// Prepare PHP arrays for chart
$years = [];
$year_totals = [];
$yearly->data_seek(0); // rewind
while ($r = $yearly->fetch_assoc()) {
    $years[] = $r['year'];
    $year_totals[] = $r['total'];
}
?>
const reportContainer = document.querySelector('#donation-report .container');
const ctx = document.createElement('canvas');
reportContainer.appendChild(ctx);

new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($years); ?>,
        datasets: [{
            label: 'Yearly Donations (₹)',
            data: <?php echo json_encode($year_totals); ?>,
            backgroundColor: '#80bcfd'
        }]
    },
    options: { responsive: true }
});
</script>

    <!-- Back to Top Button -->
<a href="#" class="back-to-top animate-fade-in"><i class="fas fa-arrow-up"></i></a>

<script>
    const RAZORPAY_KEY = "<?php echo $razorpayKeyId; ?>"; // for donation.js use
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

