
<?php
$conn = new mysqli("localhost","root","","alumni_db");
if($conn->connect_error){ die("DB failed"); }

$search = $_GET['search'] ?? '';
$type   = $_GET['type'] ?? '';
$loc    = $_GET['location'] ?? '';

function buildFilterQuery($search,$type,$loc){
    $where = "WHERE 1=1 ";
    if($search != ''){
        $s = "%$search%";
        $where .= " AND (title LIKE '$s' OR description LIKE '$s')";
    }
    if($type != ''){ $where .= " AND event_type='$type' "; }
    if($loc  != ''){ $where .= " AND location LIKE '%$loc%' "; }
    return $where;
}

$where = buildFilterQuery($search,$type,$loc);

$upcoming = $conn->query("SELECT * FROM event_listings $where AND status='upcoming' ORDER BY start_date ASC");
$past     = $conn->query("SELECT * FROM event_listings $where AND status='past' ORDER BY start_date DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Events - GEC Alumni Association</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/animations.css">
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                <li class="nav-item"><a class="nav-link" href="alumni-directory.php">Alumni</a></li>
                <li class="nav-item"><a class="nav-link active" href="events.php">Events</a></li>
                <li class="nav-item"><a class="nav-link" href="jobs.php">Jobs</a></li>
                <li class="nav-item"><a class="nav-link" href="success-stories.php">Success Stories</a></li>
                <li class="nav-item"><a class="nav-link" href="donate.php">Donate</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
                <li class="nav-item"><a class="nav-link btn-login" href="login.php">Login</a></li>
            </ul>
        </div>
    </div>
</nav>


<section class="py-5 mt-5">
 <div class="container">
  <div class="text-center mb-5">
   <h1>Upcoming Events</h1>
   <p class="lead">Join our alumni community at these exciting gatherings</p>
  </div>

  <!-- Filter Form -->
  <form method="GET" class="row mb-4 g-2">
     <div class="col-md-5">
         <input type="text" class="form-control" name="search" value="<?=$search?>" placeholder="Search events...">
     </div>
     <div class="col-md-3">
        <select class="form-select" name="type">
          <option value="">All Event Types</option>
          <option value="Reunion"    <?=($type=="Reunion")?'selected':''?>>Reunion</option>
          <option value="Workshop"   <?=($type=="Workshop")?'selected':''?>>Workshop</option>
          <option value="Conference" <?=($type=="Conference")?'selected':''?>>Conference</option>
          <option value="Networking" <?=($type=="Networking")?'selected':''?>>Networking</option>
        </select>
     </div>
     <div class="col-md-3">
        <input name="location" class="form-control" value="<?=$loc?>" placeholder="Location">
     </div>
     <div class="col-md-1 d-grid">
        <button class="btn btn-primary">Go</button>
     </div>
  </form>

  <!-- Tabs -->
  <ul class="nav nav-tabs mb-4">
    <li class="nav-item"><a data-bs-toggle="tab" href="#upTab" class="nav-link active">Upcoming</a></li>
    <li class="nav-item"><a data-bs-toggle="tab" href="#pastTab" class="nav-link">Past Events</a></li>
  </ul>

  <div class="tab-content">
   <!-- Upcoming -->
   <div id="upTab" class="tab-pane fade show active">
    <div class="row">
     <?php while($e = $upcoming->fetch_assoc()):  
            $day   = date('d',strtotime($e['start_date']));
            $month = date('M',strtotime($e['start_date']));
     ?>
      <div class="col-lg-6 mb-4">
        <div class="event-card hover-grow">
          <div class="event-date"><span class="day"><?=$day?></span><span class="month"><?=$month?></span></div>
          <div class="event-image"><img src="images/<?=$e['image']?>" class="img-fluid"></div>
          <div class="event-details">
            <h3><?=$e['title']?></h3>
            <p class="location"><i class="fas fa-map-marker-alt"></i> <?=$e['location']?></p>
            <p class="time"><i class="fas fa-clock"></i><?=date('g:i A',strtotime($e['start_date']))?> - <?=date('g:i A',strtotime($e['end_date']))?></p>
            <p><?=$e['description']?></p>
            <div class="d-flex justify-content-between align-items-center">
                <span class="badge bg-primary"><?=$e['event_type']?></span>
                <a href="#" class="btn btn-sm btn-primary">Register</a>
            </div>
          </div>
        </div>
      </div>
     <?php endwhile; ?>
    </div>
   </div>

   <!-- Past -->
   <div id="pastTab" class="tab-pane fade">
    <div class="row">
    <?php while($e = $past->fetch_assoc()):
          $day = date('d',strtotime($e['start_date']));
          $month= date('M',strtotime($e['start_date']));
    ?>
      <div class="col-lg-6 mb-4">
        <div class="event-card past-event">
          <div class="event-date"><span class="day"><?=$day?></span><span class="month"><?=$month?></span></div>
          <div class="event-image"><img src="images/<?=$e['image']?>" class="img-fluid"></div>
          <div class="event-details">
            <h3><?=$e['title']?></h3>
            <p class="location"><i class="fas fa-map-marker-alt"></i> <?=$e['location']?></p>
            <p class="time"><i class="fas fa-clock"></i> Past Event</p>
            <p><?=$e['description']?></p>
            <div class="d-flex justify-content-between">
                <span class="badge bg-secondary"><?=$e['event_type']?></span>
                <a href="#" class="btn btn-sm btn-outline-secondary">View Photos</a>
            </div>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
    </div>
   </div>
  </div>
 </div>
</section>

    <!-- Call to Action -->
    <section class="py-5 cta-section text-white text-center">
        <div class="cta-overlay"></div>
        <div class="container position-relative">
            <h2 class="mb-4">Host Your Own Alumni Event</h2>
            <p class="lead mb-5">Want to organize a reunion, workshop, or networking event for your batch or industry?</p>
            <a href="#" class="btn btn-light btn-lg me-3">Submit Event Proposal</a>
            <a href="#" class="btn btn-outline-light btn-lg">Event Guidelines</a>
        </div>
    </section>

    <!-- Footer -->
    <footer class="py-5 bg-dark text-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
                    <p>Connecting graduates of Government Engineering College across generations.</p>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="alumni-directory.php">Alumni Directory</a></li>
                        <li><a href="events.php">Events</a></li>
                        <li><a href="jobs.php">Job Portal</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5>Resources</h5>
                    <ul class="list-unstyled">
                        <li><a href="success-stories.php">Success Stories</a></li>
                        <li><a href="donate.php">Donate</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Contact Information</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt me-2"></i> Government Engineering College, Rajkot, Gujarat</li>
                        <li><i class="fas fa-phone me-2"></i> +91 9876543210</li>
                        <li><i class="fas fa-envelope me-2"></i> alumni@gec.edu.in</li>
                    </ul>
                </div>
            </div>
            <hr class="mt-4 mb-4">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">&copy; 2025 GEC Alumni Association. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <p class="mb-0"><a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <a href="#" class="back-to-top"><i class="fas fa-arrow-up"></i></a>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="js/main.js"></script>
    <script src="js/animations.js"></script>
    <script>
        // Event search and filter functionality
        document.addEventListener('DOMContentLoaded', function() {
            const eventSearch = document.getElementById('eventSearch');
            const eventSearchButton = document.getElementById('eventSearchButton');
            const eventTypeFilter = document.getElementById('eventTypeFilter');
            const eventLocationFilter = document.getElementById('eventLocationFilter');
            const eventCards = document.querySelectorAll('.event-card');
            
            function filterEvents() {
                const searchTerm = eventSearch.value.toLowerCase();
                const typeFilter = eventTypeFilter.value;
                const locationFilter = eventLocationFilter.value;
                
                eventCards.forEach(card => {
                    const cardText = card.textContent.toLowerCase();
                    const cardType = card.querySelector('.badge').textContent;
                    const cardLocation = card.querySelector('.location').textContent;
                    
                    const matchesSearch = searchTerm === '' || cardText.includes(searchTerm);
                    const matchesType = typeFilter === '' || cardType.includes(typeFilter);
                    const matchesLocation = locationFilter === '' || cardLocation.includes(locationFilter);
                    
                    if (matchesSearch && matchesType && matchesLocation) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            }
            
            // Event listeners
            eventSearchButton.addEventListener('click', filterEvents);
            eventSearch.addEventListener('keyup', function(e) {
                if (e.key === 'Enter') {
                    filterEvents();
                }
            });
            
            eventTypeFilter.addEventListener('change', filterEvents);
            eventLocationFilter.addEventListener('change', filterEvents);
        });
    </script>
</body>
</html>