<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['step'] = 1; // reset flow on fresh visit
}


// DB connection
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$step = $_SESSION['step'] ?? 1;
$error = "";
$success = "";

// Step 1: Enter Email
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']);

    if (empty($email)) {
        $error = "Please enter your email.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 0) {
            $error = "No account found with this email.";
        } else {
            // Generate OTP
            $otp = rand(100000, 999999);

            // Save OTP in DB
            $stmt->close();
            $stmt = $conn->prepare("UPDATE users SET reset_otp = ? WHERE email = ?");
            $stmt->bind_param("is", $otp, $email);
            $stmt->execute();
            $stmt->close();

            // Send OTP using PHPMailer
            require 'vendor/phpmailer/phpmailer/src/Exception.php';
            require 'vendor/phpmailer/phpmailer/src/PHPMailer.php';
            require 'vendor/phpmailer/phpmailer/src/SMTP.php';

            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);

            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com'; 
                $mail->SMTPAuth   = true;
                $mail->Username   = 'vatsalsavaliya024@gmail.com';  // 👉 CHANGE THIS
                $mail->Password   = 'xtys unji nrcc yiuy';    // 👉 CHANGE THIS
                $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                // Recipients
                $mail->setFrom('vatsalsavaliya024@gmail.com', 'GEC Alumni'); // 👉 CHANGE THIS (your name)
                $mail->addAddress($email);

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Your OTP for Password Reset';
                $mail->Body    = "Your OTP is <b>$otp</b>. It is valid for 10 minutes.";

                $mail->send();
                $success = "OTP sent to your email.";
                $_SESSION['reset_email'] = $email;
                $_SESSION['step'] = 2;
                $step = 2;
            } catch (Exception $e) {
                $error = "OTP could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        }
    }
}

// Step 2: Verify OTP
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['otp'])) {
    $otp = trim($_POST['otp']);
    $email = $_SESSION['reset_email'] ?? '';

    if (empty($otp)) {
        $error = "Please enter the OTP.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND reset_otp = ?");
        $stmt->bind_param("si", $email, $otp);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 0) {
            $error = "Invalid OTP.";
        } else {
            $success = "OTP verified! You can now reset your password.";
            $_SESSION['step'] = 3;
            $step = 3;
        }
        $stmt->close();
    }
}

// Step 3: Reset Password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['newPassword'])) {
    $newPassword = $_POST['newPassword'];
    $confirmPassword = $_POST['confirmPassword'];
    $email = $_SESSION['reset_email'] ?? '';

    if (empty($newPassword) || strlen($newPassword) < 8) {
        $error = "Password must be at least 8 characters.";
    } elseif ($newPassword !== $confirmPassword) {
        $error = "Passwords do not match.";
    } else {
        $hashed = password_hash($newPassword, PASSWORD_BCRYPT);

        $stmt = $conn->prepare("UPDATE users SET password = ?, reset_otp = NULL WHERE email = ?");
        $stmt->bind_param("ss", $hashed, $email);
        if ($stmt->execute()) {
            $success = "Password reset successful! You can now log in.";
            session_destroy();
            header("refresh:2;url=login.php"); 
            exit;
        } else {
            $error = "Error updating password.";
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Forgot Password - GEC Alumni Association</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="bg-img">

  <div class="login-wrap">
    <div class="glass-card animate-slide-up">
      <div class="text-center mb-3">
        <h3 class="mb-0"><i class="fas fa-unlock-alt"></i> Forgot Password</h3>
      </div>

      <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
      <?php endif; ?>
      <?php if (!empty($success)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
      <?php endif; ?>

      <?php if ($step == 1): ?>
        <form method="POST" action="">
          <div class="mb-3">
            <label for="email" class="form-label">Email Address</label>
            <input type="email" class="form-control" id="email" name="email" required>
          </div>
          <div class="d-grid mb-3">
            <button type="submit" class="btn btn-primary">Send OTP</button>
          </div>
          <div class="text-center">
            <a href="login.php">Back to Login</a>
          </div>
        </form>

      <?php elseif ($step == 2): ?>
        <form method="POST" action="">
          <div class="mb-3">
            <label for="otp" class="form-label">Enter OTP</label>
            <input type="number" class="form-control" id="otp" name="otp" required>
          </div>
          <div class="d-grid mb-3">
            <button type="submit" class="btn btn-primary">Verify OTP</button>
          </div>
        </form>

      <?php elseif ($step == 3): ?>
        <form method="POST" action="">
          <div class="mb-3">
            <label for="newPassword" class="form-label">New Password</label>
            <input type="password" class="form-control" id="newPassword" name="newPassword" required>
          </div>
          <div class="mb-3">
            <label for="confirmPassword" class="form-label">Confirm Password</label>
            <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required>
          </div>
          <div class="d-grid mb-3">
            <button type="submit" class="btn btn-primary">Reset Password</button>
          </div>
        </form>
      <?php endif; ?>
    </div>
  </div>

</body>
</html>
