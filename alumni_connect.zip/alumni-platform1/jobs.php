<?php
// jobs.php

// 1) DB Connection
$host     = "localhost";
$username = "root";
$password = "";
$dbname   = "alumni_db";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 2) Fetch Jobs
$sql = "SELECT * FROM jobs ORDER BY created_at DESC";
$result = $conn->query($sql);

// Helper function for time ago
function timeAgo($datetime) {
    $time = strtotime($datetime);
    $diff = time() - $time;
    if ($diff < 60)          return $diff . " seconds ago";
    elseif ($diff < 3600)    return floor($diff / 60) . " minutes ago";
    elseif ($diff < 86400)   return floor($diff / 3600) . " hours ago";
    elseif ($diff < 2592000) return floor($diff / 86400) . " days ago";
    elseif ($diff < 31536000)return floor($diff / 2592000) . " months ago";
    return floor($diff / 31536000) . " years ago";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Job Portal - GEC Alumni Association</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/animations.css">
</head>
<body>

<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                <li class="nav-item"><a class="nav-link" href="alumni-directory.php">Alumni</a></li>
                <li class="nav-item"><a class="nav-link" href="events.php">Events</a></li>
                <li class="nav-item"><a class="nav-link active" href="jobs.php">Jobs</a></li>
                <li class="nav-item"><a class="nav-link" href="success-stories.php">Success Stories</a></li>
                <li class="nav-item"><a class="nav-link" href="donate.php">Donate</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
                <li class="nav-item"><a class="nav-link btn-login" href="login.php">Login</a></li>
            </ul>
        </div>
    </div>
</nav>

<section class="py-5">
<div class="container">
    <div class="text-center mb-5">
        <h1 class="section-title animate-fade-in">Alumni Job Portal</h1>
        <p class="lead animate-fade-in animate-delay-1">Find your next career opportunity through our alumni network</p>
    </div>

    <!-- JOB LIST -->
    <?php if ($result && $result->num_rows > 0): ?>
        <p><strong><?php echo $result->num_rows; ?> jobs found</strong></p>
        <?php while($job = $result->fetch_assoc()): ?>
            <div class="job-card mb-4 animate-slide-up border p-3 rounded">
                <div class="job-header d-flex">
                    <div class="job-company-logo me-3">
                        <img src="https://placehold.co/60x60/EBF8FF/3182CE?text=<?php echo strtoupper($job['company'][0]) ?>" alt="<?php echo $job['company']; ?>">
                    </div>
                    <div class="job-info">
                        <h4><?php echo $job['title']; ?></h4>
                        <p class="company-name"><?php echo $job['company']; ?></p>
                        <div class="job-meta">
                            <span class="badge bg-primary me-2"><?php echo $job['job_type']; ?></span>
                            <span class="text-muted me-3"><i class="fas fa-map-marker-alt me-1"></i> <?php echo $job['location']; ?></span>
                            <span class="text-muted"><i class="fas fa-clock me-1"></i> Posted <?php echo timeAgo($job['created_at']); ?></span>
                        </div>
                    </div>
                </div>
                <div class="job-description mt-2">
                    <p><?php echo substr($job['description'],0,150)." ..."; ?></p>
                </div>
                <div class="job-actions d-flex">
                <a href="#" class="btn btn-outline-primary btn-sm me-2 view-details"
                    data-title="<?php echo htmlspecialchars($job['title']); ?>"
                    data-company="<?php echo htmlspecialchars($job['company']); ?>"
                    data-location="<?php echo htmlspecialchars($job['location']); ?>"
                    data-jobtype="<?php echo htmlspecialchars($job['job_type']); ?>"
                    data-experience="<?php echo htmlspecialchars($job['experience_level']); ?>"
                    data-description="<?php echo htmlspecialchars($job['description']); ?>"
                    data-apply="<?php echo htmlspecialchars($job['apply_link']); ?>"
                    data-bs-toggle="modal" data-bs-target="#jobDetailModal">View Details</a>

                    <a href="<?php echo $job['apply_link']; ?>" target="_blank" class="btn btn-primary btn-sm">Apply Now</a>
                    <span class="posted-by ms-auto">Posted by Alumni</span>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <div class="alert alert-info">No job postings found. Check back later!</div>
    <?php endif; ?>

</div>
</section>

<!-- Footer -->
<footer class="py-5 bg-dark text-white">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mb-4">
                <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
                <p>Connecting graduates of Government Engineering College across generations.</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 mb-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="alumni-directory.php">Alumni Directory</a></li>
                    <li><a href="events.php">Events</a></li>
                    <li><a href="jobs.php">Job Portal</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-6 mb-4">
                <h5>Resources</h5>
                <ul class="list-unstyled">
                    <li><a href="success-stories.php">Success Stories</a></li>
                    <li><a href="donate.php">Donate</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="col-lg-4 mb-4">
                <h5>Contact Information</h5>
                <ul class="list-unstyled">
                    <li><i class="fas fa-map-marker-alt me-2"></i> Government Engineering College, Rajkot, Gujarat</li>
                    <li><i class="fas fa-phone me-2"></i> +91 9876543210</li>
                    <li><i class="fas fa-envelope me-2"></i> alumni@gec.edu.in</li>
                </ul>
            </div>
        </div>
        <hr class="mt-4 mb-4">
        <div class="row">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-0">&copy; 2025 GEC Alumni Association. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <p class="mb-0"><a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
            </div>
        </div>
    </div>
</footer>

<!-- Job Detail Modal -->
<div class="modal fade" id="jobDetailModal" tabindex="-1" aria-labelledby="jobDetailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalJobTitle"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p><strong>Company:</strong> <span id="modalCompany"></span></p>
                <p><strong>Location:</strong> <span id="modalLocation"></span></p>
                <p><strong>Job Type:</strong> <span id="modalJobType"></span></p>
                <p><strong>Experience:</strong> <span id="modalExperience"></span></p>
                <p><strong>Description:</strong></p>
                <p id="modalDescription"></p>
            </div>
            <div class="modal-footer">
                <a href="#" id="modalApplyLink" target="_blank" class="btn btn-primary">Apply Now</a>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>



<!-- Back to Top Button -->
<a href="#" class="back-to-top animate-fade-in"><i class="fas fa-arrow-up"></i></a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/main.js"></script>
<script src="js/animations.js"></script>

</body>
</html>

<?php $conn->close(); ?>
