document.addEventListener('DOMContentLoaded', () => {
    const sidebarToggle = document.querySelector('.nav-toggle');
    const sidebar = document.querySelector('.sidebar');
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', () => sidebar.classList.toggle('active'));
    }

    const animatedElements = document.querySelectorAll('.fade-in');
    function checkScroll() {
        animatedElements.forEach(el => {
            const elPos = el.getBoundingClientRect().top;
            const screenPos = window.innerHeight / 1.3;
            if (elPos < screenPos) {
                el.style.opacity = 1;
                el.style.transform = 'translateY(0)';
            }
        });
    }
    window.addEventListener('scroll', checkScroll);
    checkScroll();

    const menuItems = document.querySelectorAll('.menu .menu-item');
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            menuItems.forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            if (window.innerWidth < 768 && sidebar) sidebar.classList.remove('active');
        });
    });

    document.addEventListener('DOMContentLoaded', () => {
        // Handle any avatar that contains a dropdown-menu
        document.querySelectorAll('.user-avatar-dropdown').forEach(avatar => {
          const dropdown = avatar.querySelector('.dropdown-menu');
          if (!dropdown) return; // this avatar has no dropdown — skip it
      
          // Toggle this avatar's dropdown on click
          avatar.addEventListener('click', (e) => {
            e.stopPropagation();
            // close other dropdowns first
            document.querySelectorAll('.user-avatar .dropdown-menu.show').forEach(d => {
              if (d !== dropdown) d.classList.remove('show');
            });
            dropdown.classList.toggle('show');
          });
        });
      
        // Click anywhere else closes all dropdowns
        document.addEventListener('click', () => {
          document.querySelectorAll('.user-avatar .dropdown-menu.show').forEach(d => d.classList.remove('show'));
        });
      
        // Close on Escape key
        document.addEventListener('keydown', (e) => {
          if (e.key === 'Escape') {
            document.querySelectorAll('.user-avatar .dropdown-menu.show').forEach(d => d.classList.remove('show'));
          }
        });
      });
      
      

    const detailModal = document.getElementById("detailModal");
    const modalBody = document.getElementById("modalBody");
    const detailClose = detailModal.querySelector(".close");

    const editModal = document.getElementById('editModal');
    const editForm = document.getElementById('editForm');
    const editClose = editModal.querySelector('.close');

    function openModal(content) {
        modalBody.innerHTML = content;
        detailModal.style.display = 'block';
    }

    function closeModal(modal) {
        modal.style.display = 'none';
    }

    detailClose.addEventListener('click', () => closeModal(detailModal));
    editClose.addEventListener('click', () => closeModal(editModal));

    window.addEventListener('click', e => {
        if (e.target === detailModal) closeModal(detailModal);
        if (e.target === editModal) closeModal(editModal);
    });

    // ==================== Action Buttons ====================
    document.body.addEventListener('click', e => {
        const btn = e.target.closest('button');
        if (!btn) return;

        const type = btn.dataset.type;
        const id = btn.dataset.id;

        // ========== View Button ==========
        if (btn.classList.contains('view-btn')) {
            fetch(`ajax/view_${type}.php?id=${id}`)
                .then(res => res.text())
                .then(data => openModal(data))
                .catch(() => openModal("Error loading details."));
        }

        // ========== Edit Button ==========
        if (btn.classList.contains('edit-btn')) {
            // Set hidden fields
            editForm.querySelector('[name="id"]').value = id;
            editForm.querySelector('[name="action"]').value = `update_${type}`;

            // Populate input fields
            editForm.querySelectorAll('input').forEach(input => {
                const key = input.name; 
                if (btn.dataset[key] !== undefined) {
                    input.value = btn.dataset[key];
                    input.closest('label, div')?.style.display = 'block';
                } else {
                    input.value = '';
                    input.closest('label, div')?.style.display = 'none';
                }
            });

            editModal.style.display = 'block';
        }

        // ========== Delete Button ==========
        if (btn.classList.contains('delete')) {
            if (!confirm(`Are you sure you want to delete this ${type}?`)) return;
            fetch(`ajax/delete_${type}.php?id=${id}`, { method: 'GET' })
                .then(res => res.text())
                .then(msg => {
                    alert(msg);
                    const row = btn.closest('tr') || btn.closest('li');
                    if (row) row.remove();
                })
                .catch(() => alert('Error deleting record.'));
        }

        // ========== Add Button ==========
        if (btn.classList.contains('add-btn')) {
            fetch(`ajax/fetch_${type}.php?mode=add`)
                .then(res => res.text())
                .then(html => {
                    modalBody.innerHTML = html;
                    detailModal.style.display = 'block';
                    const form = modalBody.querySelector('form');
                    if (form) {
                        form.addEventListener('submit', ev => {
                            ev.preventDefault();
                            const formData = new FormData(form);
                            fetch(form.action, { method: 'POST', body: formData })
                                .then(res => res.text())
                                .then(msg => {
                                    alert(msg);
                                    detailModal.style.display = 'none';
                                    location.reload();
                                });
                        });
                    }
                });
        }
    });
});

// ====== LIVE SEARCH WITH AJAX ======
document.addEventListener("DOMContentLoaded", function () {
    const input = document.getElementById("userSearchInput");
    const form = document.getElementById("userSearchForm");
    const tableContainer = document.getElementById("userTableContainer");

    if (!input || !form || !tableContainer) return; // safety check

    let timer = null;

    input.addEventListener("input", function () {
        clearTimeout(timer);
        timer = setTimeout(() => {
            const value = input.value.trim();

            // Always target dashboard.php?page=users
            const url = new URL(window.location.origin + window.location.pathname);
            url.searchParams.set("page", "users");

            if (value !== "") {
                url.searchParams.set("search", value);
            }

            fetch(url.toString(), {
                headers: { "X-Requested-With": "XMLHttpRequest" }
            })
                .then(res => res.text())
                .then(html => {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(html, "text/html");
                    const newContent = doc.querySelector("body").innerHTML.trim();

                    if (newContent) {
                        tableContainer.innerHTML = newContent;
                    } else {
                        console.warn("No table container found in AJAX response");
                    }
                })
                .catch(err => console.error("Search fetch failed:", err));
        }, 300); // debounce
    });
});
