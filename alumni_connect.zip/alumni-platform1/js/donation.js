console.log("Donation.js loaded!");

(async function () {
    const form = document.getElementById('donation-form');
    const btn = document.getElementById('donate-now');
    const resultEl = document.getElementById('result');

    function showResult(message, isError = false) {
        resultEl.textContent = message;
        resultEl.className = 'result ' + (isError ? 'text-danger' : 'text-success');
    }

    btn.addEventListener('click', async function (e) {
        e.preventDefault();
        btn.disabled = true;
        btn.textContent = 'Processing...';

        const name = document.getElementById('donor-name').value.trim();
        const email = document.getElementById('donor-email').value.trim();
        const phone = document.getElementById('donor-phone').value.trim();
        const amount = document.getElementById('donation-amount').value.trim();
        const purpose = document.getElementById('donation-purpose').value.trim();

        if (!email || !amount || isNaN(amount) || Number(amount) <= 0) {
            showResult('Please enter a valid email and amount.', true);
            btn.disabled = false;
            btn.textContent = 'Donate with Razorpay';
            return;
        }

        try {
            // 1) Create order on server (send as form-data style)
            const createResp = await fetch('create_order.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    name, 
                    email, 
                    phone, 
                    amount, 
                    purpose 
                })
            });
            

            const createJson = await createResp.json();
            if (!createJson || !createJson.success) {
                console.error('create_order error', createJson);
                showResult('Could not create order: ' + (createJson.error || JSON.stringify(createJson)), true);
                btn.disabled = false;
                btn.textContent = 'Donate with Razorpay';
                return;
            }

            const order = createJson.order;
            const donation_id = createJson.donation_id;
            const razorpayKey = createJson.razorpay_key || RAZORPAY_KEY;

            // 2) Open Razorpay checkout
            const options = {
                key: razorpayKey,
                amount: order.amount, // paise
                currency: order.currency,
                name: 'GEC Alumni Association',
                description: 'Donation for ' + purpose,
                order_id: order.id,
                handler: async function (response) {
                    try {
                        const verifyResp = await fetch('verify_payment.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                                razorpay_payment_id: response.razorpay_payment_id,
                                razorpay_order_id: response.razorpay_order_id,
                                razorpay_signature: response.razorpay_signature,
                                donation_id: donation_id
                            })
                        });
                        const verifyJson = await verifyResp.json();
                        if (verifyJson && verifyJson.success) {
                            showResult('Thank you! Donation successful. Payment ID: ' + response.razorpay_payment_id);
                        } else {
                            showResult('Payment verification failed: ' + (verifyJson.error || JSON.stringify(verifyJson)), true);
                        }
                    } catch (err) {
                        console.error(err);
                        showResult('Server error during verification.', true);
                    } finally {
                        btn.disabled = false;
                        btn.textContent = 'Donate with Razorpay';
                    }
                },
                prefill: {
                    name: name || '',
                    email: email || '',
                    contact: phone || ''
                },
                notes: {
                    donation_id: donation_id ? String(donation_id) : ''
                },
                theme: {
                    color: '#3399cc'
                }
            };

            const rzp = new Razorpay(options);
            rzp.on('payment.failed', function (response) {
                console.error('payment.failed', response);
                showResult('Payment failed: ' + (response.error && response.error.description ? response.error.description : 'Unknown error'), true);
                btn.disabled = false;
                btn.textContent = 'Donate with Razorpay';
            });

            rzp.open();

        } catch (err) {
            console.error(err);
            showResult('Unexpected error: ' + err.message, true);
            btn.disabled = false;
            btn.textContent = 'Donate with Razorpay';
        }
    });
})();

/* -------------------------------
   Donation Charts
--------------------------------*/
if (window.donationYearly && window.donationYearly.years.length > 0) {
    const container = document.querySelector('#donation-report .container');
    if (container) {
        const chartSection = document.createElement('div');
        chartSection.classList.add('mt-5');
        chartSection.innerHTML = '<h4>📊 Yearly Donation Trends</h4><canvas id="donationChart"></canvas>';
        container.appendChild(chartSection);

        const ctx = document.getElementById('donationChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: window.donationYearly.years,
                datasets: [{
                    label: 'Yearly Donations (₹)',
                    data: window.donationYearly.totals,
                    backgroundColor: '#80bcfd'
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: {
                    y: {
                        ticks: { callback: value => '₹' + value }
                    }
                }
            }
        });
    }
}
