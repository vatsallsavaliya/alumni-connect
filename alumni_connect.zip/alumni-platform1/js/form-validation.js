document.addEventListener('DOMContentLoaded', function() {
    // Registration Form Validation
    const registrationForm = document.getElementById('registrationForm');
    if (registrationForm) {
        registrationForm.addEventListener('submit', function(e) {
            let isValid = true;
            
            // Validate fields
            const firstName = document.getElementById('firstName');
            const lastName = document.getElementById('lastName');
            const email = document.getElementById('email');
            const password = document.getElementById('password');
            const confirmPassword = document.getElementById('confirmPassword');
            const graduationYear = document.getElementById('graduationYear');
            const degree = document.getElementById('degree');
            
            // Reset errors
            document.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
            document.querySelectorAll('.invalid-feedback').forEach(el => el.style.display = 'none');
            
            // First Name
            if (!firstName.value.trim()) {
                firstName.classList.add('is-invalid');
                document.getElementById('firstNameError').style.display = 'block';
                isValid = false;
            }
            
            // Last Name
            if (!lastName.value.trim()) {
                lastName.classList.add('is-invalid');
                document.getElementById('lastNameError').style.display = 'block';
                isValid = false;
            }
            
            // Email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!email.value.trim() || !emailRegex.test(email.value)) {
                email.classList.add('is-invalid');
                document.getElementById('emailError').style.display = 'block';
                isValid = false;
            }
            
            // Password
            if (password.value.length < 8) {
                password.classList.add('is-invalid');
                document.getElementById('passwordError').style.display = 'block';
                isValid = false;
            }
            
            // Confirm Password
            if (password.value !== confirmPassword.value) {
                confirmPassword.classList.add('is-invalid');
                document.getElementById('confirmPasswordError').style.display = 'block';
                isValid = false;
            }
            
            // Graduation Year
            const currentYear = new Date().getFullYear();
            const gradYear = parseInt(graduationYear.value.trim(), 10);

            if (isNaN(gradYear) || gradYear < 1950 ) {
                graduationYear.classList.add('is-invalid');
                document.getElementById('graduationYearError').style.display = 'block';
                isValid = false;
            }
            
            // Degree
            if (!degree.value.trim()) {
                degree.classList.add('is-invalid');
                document.getElementById('degreeError').style.display = 'block';
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault(); // Prevent submission if invalid
            }
            // If valid, allow default form submission (no JS redirect or alert)
        });
    }
    
    // Login Form Validation
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            let isValid = true;
            
            const email = document.getElementById('loginEmail');
            const password = document.getElementById('loginPassword');
            
            // Reset errors
            document.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));
            document.querySelectorAll('.invalid-feedback').forEach(el => el.style.display = 'none');
            
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!email.value.trim() || !emailRegex.test(email.value)) {
                email.classList.add('is-invalid');
                isValid = false;
            }
            
            if (!password.value.trim()) {
                password.classList.add('is-invalid');
                document.getElementById('loginPasswordError').style.display = 'block';
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault(); // Prevent submission if invalid
            }
            // If valid, allow form submission to PHP login handler (no JS alerts or redirects)
        });
    }
});
