console.log("profile.js loaded");

document.addEventListener("DOMContentLoaded", function () {
  const tabButtons = document.querySelectorAll(".tab-button");
  const tabContents = document.querySelectorAll(".tab-content");

  function showTab(targetId) {
    tabContents.forEach(content => {
      content.style.display = content.id === targetId ? "block" : "none";
    });
    tabButtons.forEach(button => {
      button.classList.toggle("active", button.getAttribute("data-target") === targetId);
    });
  }

  tabButtons.forEach(button => {
    button.addEventListener("click", function () {
      const target = this.getAttribute("data-target");
      showTab(target);
      history.replaceState(null, null, `#${target}`);
    });
  });

  // On page load, show correct tab
  const initialTab = window.location.hash.substring(1) || tabButtons[0].getAttribute("data-target");
  showTab(initialTab);
});
