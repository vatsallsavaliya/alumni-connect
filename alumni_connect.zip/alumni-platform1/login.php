<?php
session_start();

// DB connection
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$loginError = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST['loginEmail'] ?? '');
    $passwordInput = trim($_POST['loginPassword'] ?? '');

    if (empty($email) || empty($passwordInput)) {
        $loginError = "Please enter both email and password.";
    } else {
        // First check in admins table
        $stmt = $conn->prepare("SELECT id, name, email, password, role FROM admins WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        // If not found in admins, check in users table
        if (!$result || $result->num_rows === 0) {
            $stmt = $conn->prepare("SELECT id, name, email, password, role FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
        }

        if ($result && $result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (password_verify($passwordInput, $user['password'])) {
                // Successful login
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['role'] = $user['role'];

                if ($user['role'] === 'admin' || $user['role'] === 'superadmin') {
                    header("Location: admin/dashboard.php");
                } else {
                    header("Location: profile.php");
                }
                exit();
            } else {
                $loginError = "Invalid email or password.";
            }
        } else {
            $loginError = "Invalid email or password.";
        }

        $stmt->close();
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Login - GEC Alumni Association</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Your custom CSS -->
  <link rel="stylesheet" href="css/style.css">
  <!-- optional animations file -->
  <link rel="stylesheet" href="css/animations.css">
</head>
<body class="bg-img">


  <!-- Centered glassy login card -->
  <div class="login-wrap">
    <div class="glass-card animate-slide-up">
      <div class="text-center mb-3">
        <h3 class="mb-0"><i class="fas fa-user-circle"></i> Welcome Back</h3>
        <small class="d-block text-muted">Login to your GEC Alumni account</small>
      </div>

      <?php if (!empty($loginError)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($loginError) ?></div>
      <?php endif; ?>

      <form id="loginForm" method="POST" action="login.php" novalidate>
        <div class="mb-3">
          <label for="loginEmail" class="form-label">Email address</label>
          <input type="email" class="form-control" id="loginEmail" name="loginEmail" required>
          <div class="invalid-feedback">Please enter a valid email.</div>
        </div>

        <div class="mb-3">
          <label for="loginPassword" class="form-label">Password</label>
          <input type="password" class="form-control" id="loginPassword" name="loginPassword" required>
          <div class="invalid-feedback">Please enter your password.</div>
        </div>

        <div class="mb-3 d-flex justify-content-between align-items-center">
          <div class="form-check">
            <input type="checkbox" class="form-check-input" id="rememberMe">
            <label class="form-check-label" for="rememberMe">Remember me</label>
          </div>
          <a href="forgot-password.php" class="small">Forgot password?</a>
        </div>

        <div class="d-grid mb-3">
          <button type="submit" class="btn btn-primary btn-glass">Login</button>
        </div>

        <div class="text-center">
          <p class="mb-1">Don't have an account? <a href="register.php">Register</a></p>
          <div class="social-login mt-2">
            <a href="#" class="btn btn-outline-light me-2"><i class="fab fa-google"></i></a>
            <a href="#" class="btn btn-outline-light me-2"><i class="fab fa-facebook-f"></i></a>
            <a href="#" class="btn btn-outline-light"><i class="fab fa-linkedin-in"></i></a>
          </div>
        </div>
      </form>
    </div>
  </div>


  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="js/form-validation.js"></script>
  <script src="js/main.js"></script>
  <script src="js/animations.js"></script>
</body>
</html>
