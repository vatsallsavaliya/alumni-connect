<?php
session_start();

// DB connection
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user info
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

$skills = $conn->query("SELECT * FROM skills WHERE user_id = $user_id") ?: null;
$experience = $conn->query("SELECT * FROM experience WHERE user_id = $user_id") ?: null;
$eventRegs = $conn->query("SELECT er.*, el.title, el.start_date, el.end_date, el.location 
                           FROM event_registrations er
                           JOIN event_listings el ON er.event_id = el.id
                           WHERE er.email = '".$conn->real_escape_string($user['email'])."'") ?: null;
$events = $conn->query("SELECT * FROM event_listings WHERE status = 'active' ORDER BY start_date ASC") ?: null;





// Fetch event registrations by user
$eventRegs = $conn->query("SELECT er.*, el.title, el.start_date, el.end_date, el.location 
                           FROM event_registrations er
                           JOIN event_listings el ON er.event_id = el.id
                           WHERE er.email = '".$conn->real_escape_string($user['email'])."'");

// Fetch upcoming events (for browsing)
$events = $conn->query("SELECT * FROM event_listings WHERE status = 'active' ORDER BY start_date ASC");

/* === Donations summary (safe even if table doesn't exist) === */
$donations = ['total' => 0, 'count' => 0];
$donationsTableExists = false;

try {
    // Check if donations table exists in this DB
    $chkSql = "SELECT 1
               FROM information_schema.tables
               WHERE table_schema = DATABASE() 
                 AND LOWER(table_name) = 'donations'
               LIMIT 1";
    if ($chkRes = $conn->query($chkSql)) {
        $donationsTableExists = $chkRes->num_rows > 0;
        $chkRes->free();
    }

    if ($donationsTableExists) {
        // Safe query
        $stmt = $conn->prepare("
            SELECT COALESCE(SUM(amount),0) AS total, COUNT(*) AS cnt
            FROM donations
            WHERE user_id = ?
        ");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($res) {
            $donations['total'] = (float)$res['total'];
            $donations['count'] = (int)$res['cnt'];
        }
    }
} catch (mysqli_sql_exception $e) {
    error_log("Donations query failed: " . $e->getMessage());
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GEC Alumni Association</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/animations.css">
    <link rel="stylesheet" href="css/profile.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                <li class="nav-item"><a class="nav-link" href="alumni-directory.php">Alumni</a></li>
                <li class="nav-item"><a class="nav-link" href="events.php">Events</a></li>
                <li class="nav-item"><a class="nav-link" href="jobs.php">Jobs</a></li>
                <li class="nav-item"><a class="nav-link" href="success-stories.php">Success Stories</a></li>
                <li class="nav-item"><a class="nav-link" href="donate.php">Donate</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
                <?php if(isset($_SESSION['user_id'])): 
    $navbarUserId = $_SESSION['user_id'];
    $stmt = $conn->prepare("SELECT profile_image FROM users WHERE id = ?");
    $stmt->bind_param("i", $navbarUserId);
    $stmt->execute();
    $navbarUser = $stmt->get_result()->fetch_assoc();
    $stmt->close();
?>
<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
        <img src="<?= htmlspecialchars($navbarUser['profile_image'] ?: 'images/default-avatar.png') ?>" 
             alt="Profile" class="rounded-circle" width="30" height="30">
    </a>
    <ul class="dropdown-menu dropdown-menu-end">
        <li><a class="dropdown-item" href="logout.php">Logout</a></li>
    </ul>
</li>
<?php else: ?>
<li class="nav-item"><a class="nav-link btn-login" href="login.php">Login</a></li>
<?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

    <div class="profile-container">
        <!-- Profile Header -->
        <div class="profile-header">
        <img src="<?= htmlspecialchars($user['profile_image'] ?: 'images/default-avatar.png') ?>" 
     alt="Profile Image" class="profile-image">

            <h2><?= htmlspecialchars($user['name']) ?></h2>
            <p class="bio"><?= htmlspecialchars($user['bio'] ?: 'No bio added yet.') ?></p>
            <p class="member-since">Member since <?= date("F j, Y", strtotime($user['created_at'])) ?></p>
        </div>

        <!-- Tabs -->
        <div class="tabs">
        <button class="tab-button active" data-target="overview">Overview</button>
        <button class="tab-button" data-target="skills">Skills</button>
        <button class="tab-button" data-target="experience">Experience</button>
        <button class="tab-button" data-target="jobs">Jobs</button>
        <button class="tab-button" data-target="events">Events</button>
        <button class="tab-button" data-target="donations">Donations</button>

        </div>

        <!-- Overview Tab -->
        <div id="overview" class="tab-content active">
            <h3>Personal Information</h3>
            <ul>
                <li><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></li>
                <li><strong>Phone:</strong> <?= htmlspecialchars($user['phone']) ?></li>
                <li><strong>Graduation Year:</strong> <?= htmlspecialchars($user['graduation_year']) ?></li>
                <li><strong>Department:</strong> <?= htmlspecialchars($user['department']) ?></li>
                <li><strong>Role:</strong> <?= htmlspecialchars($user['role']) ?></li>
            </ul>
        </div>

        <!-- Skills Tab -->
        <div id="skills" class="tab-content">
            <h3>Skills</h3>
            <?php if ($skills->num_rows > 0): ?>
                <ul>
                    <?php while ($s = $skills->fetch_assoc()): ?>
                        <li><?= htmlspecialchars($s['skill_name']) ?> - <?= htmlspecialchars($s['level']) ?></li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>No skills added yet.</p>
            <?php endif; ?>
        </div>

        <!-- Experience Tab -->
        <div id="experience" class="tab-content">
            <h3>Experience</h3>
            <?php if ($experience->num_rows > 0): ?>
                <?php while ($exp = $experience->fetch_assoc()): ?>
                    <div class="experience-card">
                        <h4><?= htmlspecialchars($exp['position']) ?> @ <?= htmlspecialchars($exp['company']) ?></h4>
                        <p><strong><?= $exp['start_date'] ?> - <?= $exp['end_date'] ?: 'Present' ?></strong></p>
                        <p><?= htmlspecialchars($exp['location']) ?></p>
                        <p><?= htmlspecialchars($exp['description']) ?></p>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No work experience added yet.</p>
            <?php endif; ?>
        </div>


        <!-- Events Tab -->
        <div id="events" class="tab-content">
            <h3>My Event Registrations</h3>
            <?php if ($eventRegs->num_rows > 0): ?>
                <ul>
                    <?php while ($reg = $eventRegs->fetch_assoc()): ?>
                        <li>
                            <?= htmlspecialchars($reg['title']) ?> 
                            (<?= htmlspecialchars($reg['start_date']) ?> to <?= htmlspecialchars($reg['end_date']) ?>) 
                            @ <?= htmlspecialchars($reg['location']) ?>
                        </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <p>You haven’t registered for any events yet.</p>
            <?php endif; ?>

            <h3>Upcoming Events</h3>
            <?php if ($events->num_rows > 0): ?>
                <?php while ($ev = $events->fetch_assoc()): ?>
                    <div class="event-card">
                        <h4><?= htmlspecialchars($ev['title']) ?></h4>
                        <p><?= htmlspecialchars($ev['description']) ?></p>
                        <p><strong><?= $ev['start_date'] ?> - <?= $ev['end_date'] ?></strong></p>
                        <p>@ <?= htmlspecialchars($ev['location']) ?></p>
                        <button class="btn">Register</button>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No upcoming events.</p>
            <?php endif; ?>
        </div>

        <div id="donations" class="tab-content">
    <h3>Donations</h3>
    <?php if ($donationsTableExists): ?>
        <div class="donation-summary">
            <p><strong>Total Donated:</strong> ₹<?= number_format($donations['total'], 2) ?></p>
            <p><strong>Donations Made:</strong> <?= $donations['count'] ?></p>
            <?php if ($donations['count'] === 0): ?>
                <p>No donations recorded yet.</p>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <p>Donations feature is not enabled in this system.</p>
    <?php endif; ?>
</div>
</div>

<!-- Footer -->
<footer class="py-5 bg-dark text-white">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mb-4">
                <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
                <p>Connecting graduates of Government Engineering College across generations.</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-md-6 mb-4">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="alumni-directory.php">Alumni Directory</a></li>
                    <li><a href="events.php">Events</a></li>
                    <li><a href="jobs.php">Job Portal</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-md-6 mb-4">
                <h5>Resources</h5>
                <ul class="list-unstyled">
                    <li><a href="success-stories.php">Success Stories</a></li>
                    <li><a href="donate.php">Donate</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
            <div class="col-lg-4 mb-4">
                <h5>Contact Information</h5>
                <ul class="list-unstyled">
                    <li><i class="fas fa-map-marker-alt me-2"></i> Government Engineering College, Rajkot, Gujarat</li>
                    <li><i class="fas fa-phone me-2"></i> +91 9876543210</li>
                    <li><i class="fas fa-envelope me-2"></i> alumni@gec.edu.in</li>
                </ul>
            </div>
        </div>
        <hr class="mt-4 mb-4">
        <div class="row">
            <div class="col-md-6 text-center text-md-start">
                <p class="mb-0">&copy; 2025 GEC Alumni Association. All rights reserved.</p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <p class="mb-0"><a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
            </div>
        </div>
    </div>
</footer>

<!-- Back to Top Button -->
<a href="#" class="back-to-top animate-fade-in"><i class="fas fa-arrow-up"></i></a>

<script src="js/profile.js"></script>
<script src="js/main.js"></script>
<script src="js/animations.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    </body>
</html>
