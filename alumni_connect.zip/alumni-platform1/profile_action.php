<?php
session_start();
include 'admin/db_connect.php';

if (!isset($_SESSION['user_id'])) {
    echo "User not logged in";
    exit;
}

$user_id = $_SESSION['user_id'];

// Update Education
if (isset($_POST['education_degree'])) {
    foreach ($_POST['education_degree'] as $index => $degree) {
        $id = $_POST['education_id'][$index];
        $institution = $_POST['education_institution'][$index];
        $start = $_POST['education_start'][$index];
        $end = $_POST['education_end'][$index];

        if (!empty($degree) && !empty($institution)) {
            if ($id) {
                $stmt = $conn->prepare("UPDATE education SET degree=?, institution=?, start_year=?, end_year=? WHERE id=? AND user_id=?");
                $stmt->bind_param("sssiii", $degree, $institution, $start, $end, $id, $user_id);
            } else {
                $stmt = $conn->prepare("INSERT INTO education (user_id, degree, institution, start_year, end_year) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("issss", $user_id, $degree, $institution, $start, $end);
            }
            $stmt->execute();
        }
    }
}

// Update Experience
if (isset($_POST['experience_role'])) {
    foreach ($_POST['experience_role'] as $index => $role) {
        $id = $_POST['experience_id'][$index];
        $company = $_POST['experience_company'][$index];
        $start = $_POST['experience_start'][$index];
        $end = $_POST['experience_end'][$index];

        if (!empty($role) && !empty($company)) {
            if ($id) {
                $stmt = $conn->prepare("UPDATE experience SET role=?, company=?, start_year=?, end_year=? WHERE id=? AND user_id=?");
                $stmt->bind_param("sssiii", $role, $company, $start, $end, $id, $user_id);
            } else {
                $stmt = $conn->prepare("INSERT INTO experience (user_id, role, company, start_year, end_year) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("issss", $user_id, $role, $company, $start, $end);
            }
            $stmt->execute();
        }
    }
}

// Update Skills
if (!empty($_POST['skills'])) {
    $conn->query("DELETE FROM skills WHERE user_id = $user_id");
    $skills = explode(',', $_POST['skills']);
    foreach ($skills as $skill) {
        $skill = trim($skill);
        if (!empty($skill)) {
            $stmt = $conn->prepare("INSERT INTO skills (user_id, skill_name) VALUES (?, ?)");
            $stmt->bind_param("is", $user_id, $skill);
            $stmt->execute();
        }
    }
}

// Update Social Links
$linkedin = $_POST['linkedin'] ?? '';
$github = $_POST['github'] ?? '';
$twitter = $_POST['twitter'] ?? '';
$website = $_POST['website'] ?? '';

if ($conn->query("SELECT * FROM social_links WHERE user_id = $user_id")->num_rows > 0) {
    $stmt = $conn->prepare("UPDATE social_links SET linkedin=?, github=?, twitter=?, website=? WHERE user_id=?");
    $stmt->bind_param("ssssi", $linkedin, $github, $twitter, $website, $user_id);
} else {
    $stmt = $conn->prepare("INSERT INTO social_links (user_id, linkedin, github, twitter, website) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $user_id, $linkedin, $github, $twitter, $website);
}
$stmt->execute();

echo "Profile updated successfully!";
?>
