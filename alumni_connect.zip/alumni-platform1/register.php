<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$registerError = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName       = trim($_POST['firstName'] ?? '');
    $lastName        = trim($_POST['lastName'] ?? '');
    $email           = trim($_POST['email'] ?? '');
    $passwordInput   = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';
    $graduationYear  = $_POST['graduationYear'] ?? '';
    $degree          = trim($_POST['degree'] ?? '');

    if (empty($firstName) || empty($lastName) || empty($email) || empty($passwordInput) || empty($graduationYear) || empty($degree)) {
        $registerError = "All required fields must be filled.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $registerError = "Invalid email address.";
    } elseif ($passwordInput !== $confirmPassword) {
        $registerError = "Passwords do not match.";
    } elseif (strlen($passwordInput) < 8) {
        $registerError = "Password must be at least 8 characters.";
    } elseif (empty($graduationYear) || $graduationYear < 1950) {
        $registerError = "Please enter a valid graduation year (1950 or later).";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $registerError = "Email is already registered.";
        }
        $stmt->close();

        if (empty($registerError)) {
            $hashedPassword = password_hash($passwordInput, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, password, graduation_year, department, role) VALUES (?, ?, ?, ?, ?, 'user')");
            $fullName = $firstName . " " . $lastName;
            $stmt->bind_param("sssis", $fullName, $email, $hashedPassword, $graduationYear, $degree);
            if ($stmt->execute()) {
                header("Location: login.php?registered=1");
                exit();
            } else {
                $registerError = "Error: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Register - GEC Alumni Association</title>

  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/animations.css">
</head>
<body class="bg-img">

  <!-- Register Card -->
  <div class="login-wrap">
    <div class="glass-card animate-slide-up">
      <div class="text-center mb-3">
        <h3 class="mb-0"><i class="fas fa-user-plus"></i> Create an Account</h3>
        <small class="d-block text-muted">Join the GEC Alumni Network</small>
      </div>

      <?php if (!empty($registerError)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($registerError) ?></div>
      <?php endif; ?>

      <form id="registrationForm" method="POST" action="register.php" novalidate>
        <div class="row">
          <div class="col-md-6 mb-3">
            <label for="firstName" class="form-label">First Name</label>
            <input type="text" class="form-control" id="firstName" name="firstName" required>
            <div id="firstNameError" class="invalid-feedback">Please enter your first name.</div>
          </div>
          <div class="col-md-6 mb-3">
            <label for="lastName" class="form-label">Last Name</label>
            <input type="text" class="form-control" id="lastName" name="lastName" required>
            <div id="lastNameError" class="invalid-feedback">Please enter your last name.</div>
          </div>
        </div>

        <div class="mb-3">
          <label for="email" class="form-label">Email Address</label>
          <input type="email" class="form-control" id="email" name="email" required>
          <div id="emailError" class="invalid-feedback">Please enter a valid email.</div>
        </div>

        <div class="row">
          <div class="col-md-6 mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" class="form-control" id="password" name="password" required>
            <div id="passwordError" class="invalid-feedback">Password must be at least 8 characters.</div>
          </div>
          <div class="col-md-6 mb-3">
            <label for="confirmPassword" class="form-label">Confirm Password</label>
            <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required>
            <div id="confirmPasswordError" class="invalid-feedback">Passwords do not match.</div>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6 mb-3">
            <label for="graduationYear" class="form-label">Graduation Year</label>
            <input type="number" 
       class="form-control" 
       id="graduationYear" 
       name="graduationYear" 
       min="1950" 
       max="<?= date('Y') ?>" 
       required>
<div id="graduationYearError" class="invalid-feedback">Please enter a valid graduation year.</div>
            <div id="graduationYearError" class="invalid-feedback">Please enter a valid graduation year.</div>
          </div>
          <div class="col-md-6 mb-3">
            <label for="degree" class="form-label">Degree</label>
            <select class="form-select" id="degree" name="degree" required>
              <option value="">Select Degree</option>
              <option value="B.Tech">B.Tech</option>
              <option value="M.Tech">M.Tech</option>
              <option value="PhD">PhD</option>
              <option value="Other">Other</option>
            </select>
            <div id="degreeError" class="invalid-feedback">Please select your degree.</div>
          </div>
        </div>

        <div class="mb-3 form-check">
          <input class="form-check-input" type="checkbox" id="terms" required>
          <label class="form-check-label" for="terms">
            I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>
          </label>
          <div class="invalid-feedback">You must agree to the terms.</div>
        </div>

        <div class="d-grid mb-3">
          <button type="submit" class="btn btn-primary btn-glass">Register</button>
        </div>

        <div class="text-center">
          <p class="mb-1">Already have an account? <a href="login.php">Login</a></p>
        </div>
      </form>
    </div>
  </div>

  <!-- Scripts -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="js/form-validation.js"></script>
  <script src="js/main.js"></script>
  <script src="js/animations.js"></script>
</body>
</html>
