<?php
$conn = new mysqli("localhost", "root", "", "alumni_db");
if ($conn->connect_error) { 
    die("Connection failed: " . $conn->connect_error); 
}

$adminPassword = 'Admin@123'; // your new admin password
$hashed = password_hash($adminPassword, PASSWORD_DEFAULT); // safely hash it
$adminEmail = 'rohan.sharma@gec.in'; // your admin email

$stmt = $conn->prepare("UPDATE admins SET password=? WHERE email=?");
$stmt->bind_param("ss", $hashed, $adminEmail);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "Admin password updated successfully.";
} else {
    echo "No admin found with that email.";
}

$stmt->close();
$conn->close();
?>
