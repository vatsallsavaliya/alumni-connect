<?php
// Database connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "alumni_db";

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST['name']);
    $title = trim($_POST['title']);
    $story = trim($_POST['story']);
    $created_at = date('Y-m-d H:i:s');

    // Image upload
    $imagePath = null;
    if (!empty($_FILES['image']['name'])) {
        $targetDir = "images/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true); // Create directory if not exists
        }
    
        $fileName = time() . "_" . basename($_FILES['image']['name']);
        $targetFile = $targetDir . $fileName;
    
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            // Store relative path in DB
            $imagePath = "images/" . $fileName;
        }
    }
    

    // Insert into DB
    $stmt = $conn->prepare("INSERT INTO success_spotlights (name, title, image, story, created_at) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $title, $imagePath, $story, $created_at);

    if ($stmt->execute()) {
        echo "<script>alert('Story submitted successfully!'); window.location.href='success-stories.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
