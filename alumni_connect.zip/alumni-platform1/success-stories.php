<?php
// DB connection
$servername = "localhost";
$username = "root"; // Change if needed
$password = "";     // Change if needed
$dbname = "alumni_db";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Pagination settings
$stories_per_page = 6;
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $stories_per_page;

// Count total stories
$total_sql = "SELECT COUNT(*) AS total FROM success_spotlights";
$total_result = $conn->query($total_sql);
$total_stories = $total_result->fetch_assoc()['total'];
$total_pages = ceil($total_stories / $stories_per_page);

// Fetch paginated stories
$sql = "SELECT * FROM success_spotlights ORDER BY id DESC LIMIT $offset, $stories_per_page";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success Stories - GEC Alumni Association</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/animations.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About</a></li>
                    <li class="nav-item"><a class="nav-link" href="alumni-directory.php">Alumni</a></li>
                    <li class="nav-item"><a class="nav-link" href="events.php">Events</a></li>
                    <li class="nav-item"><a class="nav-link" href="jobs.php">Jobs</a></li>
                    <li class="nav-item"><a class="nav-link active" href="success-stories.php">Success Stories</a></li>
                    <li class="nav-item"><a class="nav-link" href="donate.php">Donate</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact Us</a></li>
                    <li class="nav-item"><a class="nav-link btn-login" href="login.php">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Success Stories Hero -->
    <section class="success-hero py-5 text-white">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8 mx-auto text-center animate-fade-in">
                    <h1 class="display-4 fw-bold mb-4">Alumni Success Stories</h1>
                    <p class="lead mb-4">Discover how GEC graduates are making an impact around the world</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Dynamic Stories -->
    <section id="stories" class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="section-title animate-fade-in">Our Alumni Stories</h2>
                <p class="lead animate-fade-in animate-delay-1">Inspiring stories from our accomplished graduates</p>
            </div>
            <div class="row">
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <div class="col-lg-4 mb-4 animate-slide-up">
                            <div class="story-card hover-grow">
                                <div class="story-image">
                                    <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" class="alumni-photo">
                                </div>
                                <div class="story-content">
                                    <div class="story-meta">
                                        <span class="badge bg-primary"><?php echo htmlspecialchars($row['category'] ?? ''); ?></span>
                                        <span class="text-muted"><?php echo htmlspecialchars($row['graduation_year'] ?? ''); ?></span>
                                    </div>
                                    <h4><?php echo htmlspecialchars($row['name']); ?></h4>
                                    <p><?php echo htmlspecialchars($row['title']); ?></p>
                                    <p><?php echo substr(strip_tags($row['story']), 0, 100) . '...'; ?></p>
                                    <button class="btn btn-primary read-more-btn"
                                        data-name="<?php echo htmlspecialchars($row['name']); ?>"
                                        data-image="<?php echo htmlspecialchars($row['image']); ?>"
                                        data-bio="<?php echo htmlspecialchars($row['bio'] ?? ''); ?>"
                                        data-story="<?php echo htmlspecialchars($row['story']); ?>"
                                        data-year="<?php echo htmlspecialchars($row['graduation_year'] ?? ''); ?>"
                                        data-department="<?php echo htmlspecialchars($row['department'] ?? ''); ?>"
                                        data-bs-toggle="modal" data-bs-target="#storyModal">
                                        Read More
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="col-12 text-center">
                        <p>No stories found.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Pagination -->
            <nav>
                <ul class="pagination justify-content-center mt-4">
                    <?php if ($page > 1): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page-1; ?>">&laquo; Prev</a></li>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $page+1; ?>">Next &raquo;</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </section>

    <!-- Share Your Story -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0 animate-slide-right">
                    <h2 class="mb-4">Share Your Success Story</h2>
                    <p class="lead">Your journey could inspire current and future students!</p>
                    <p>We love hearing about the achievements of our alumni community...</p>
                </div>
                <div class="col-lg-6 animate-slide-left">
                    <div class="card shadow-sm">
                        <div class="card-body p-4">
                            <h3 class="mb-4">Submit Your Story</h3>
                            <form action="submit_story.php" method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="yourName" class="form-label">Your Name</label>
                                    <input type="text" class="form-control" id="yourName" name="name" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="storyTitle" class="form-label">Story Title</label>
                                    <input type="text" class="form-control" id="storyTitle" name="title" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="storyContent" class="form-label">Your Story</label>
                                    <textarea class="form-control" id="storyContent" name="story" rows="4" required></textarea>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="storyPhoto" class="form-label">Photo (Optional)</label>
                                    <input type="file" class="form-control" id="storyPhoto" name="image" accept="image/*">
                                </div>
                                
                                <button type="submit" class="btn btn-primary">Submit Story</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

     <!-- Footer -->
     <footer class="py-5 bg-dark text-white">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <img src="images/Rajkot__1_-removebg-preview.png" alt="GEC Alumni" height="60">
                    <p>Connecting graduates of Government Engineering College across generations.</p>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5>Quick Links</h5>
                    <ul class="list-unstyled">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="alumni-directory.php">Alumni Directory</a></li>
                        <li><a href="events.php">Events</a></li>
                        <li><a href="jobs.php">Job Portal</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5>Resources</h5>
                    <ul class="list-unstyled">
                        <li><a href="success-stories.php">Success Stories</a></li>
                        <li><a href="donate.php">Donate</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
                <div class="col-lg-4 mb-4">
                    <h5>Contact Information</h5>
                    <ul class="list-unstyled">
                        <li><i class="fas fa-map-marker-alt me-2"></i> Government Engineering College, Rajkot, Gujarat</li>
                        <li><i class="fas fa-phone me-2"></i> +91 9876543210</li>
                        <li><i class="fas fa-envelope me-2"></i> alumni@gec.edu.in</li>
                    </ul>
                </div>
            </div>
            <hr class="mt-4 mb-4">
            <div class="row">
                <div class="col-md-6 text-center text-md-start">
                    <p class="mb-0">&copy; 2025 GEC Alumni Association. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <p class="mb-0"><a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
                </div>
            </div>
        </div>
    </footer>

    <div class="modal fade" id="storyModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalName"></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">
        <img id="modalImage" class="rounded-circle mb-3" width="120" height="120" alt="Alumni Photo">

        <p id="modalBio"></p>
        <hr>
        <p id="modalStory"></p>
      </div>
    </div>
  </div>
</div>




    <!-- Back to Top Button -->
    <a href="#" class="back-to-top"><i class="fas fa-arrow-up"></i></a>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/animations.js"></script>
</body>
</html>
<?php $conn->close(); ?>
