<?php
// test_chat.php - quick test for ai_chat.php
$ch = curl_init('http://localhost/alumni-platform1/api/ai_chat.php'); // adjust URL if needed
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode([
        'messages' => [
            ['role' => 'user', 'content' => 'Hello! Can you tell me about alumni events?']
        ]
    ])
]);
$response = curl_exec($ch);
curl_close($ch);

header('Content-Type: application/json');
echo $response;
