<?php
// verify_payment.php
// Verifies the signature sent by Razorpay after checkout and updates DB.

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/razorpay_config.php';

$input = json_decode(file_get_contents('php://input'), true);

// Expected: razorpay_payment_id, razorpay_order_id, razorpay_signature
$payment_id = $input['razorpay_payment_id'] ?? null;
$order_id = $input['razorpay_order_id'] ?? null;
$signature = $input['razorpay_signature'] ?? null;

if (!$payment_id || !$order_id || !$signature) {
    echo json_encode(['error' => 'Missing parameters']);
    exit;
}

// Compute expected signature: hmac_sha256(order_id + '|' + payment_id, secret)
$data = $order_id . '|' . $payment_id;
$expected_signature = hash_hmac('sha256', $data, $razorpayKeySecret);

if (!hash_equals($expected_signature, $signature)) {
    // signature mismatch
    // update DB: mark failed
    $stmt = $conn->prepare("UPDATE donations SET status = ?, payment_id = ?, signature = ?, updated_at = NOW() WHERE order_id = ?");
    $failed_status = 'failed_verification';
    if ($stmt) {
        $stmt->bind_param('ssss', $failed_status, $payment_id, $signature, $order_id);
        $stmt->execute();
        $stmt->close();
    }
    echo json_encode(['error' => 'Invalid signature']);
    exit;
}

// signature valid -> update DB as paid
$stmt = $conn->prepare("UPDATE donations SET status = ?, payment_id = ?, signature = ?, updated_at = NOW() WHERE order_id = ?");
$paid_status = 'paid';
if (!$stmt) {
    echo json_encode(['error' => 'DB prepare failed: ' . $conn->error]);
    exit;
}
$stmt->bind_param('ssss', $paid_status, $payment_id, $signature, $order_id);
$ok = $stmt->execute();
if (!$ok) {
    echo json_encode(['error' => 'DB update failed: ' . $stmt->error]);
    exit;
}
$stmt->close();

// Optionally fetch donation row to return
$stmt = $conn->prepare("SELECT id, amount_paise, name, email FROM donations WHERE order_id = ? LIMIT 1");
if ($stmt) {
    $stmt->bind_param('s', $order_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
} else {
    $row = null;
}

echo json_encode([
    'success' => true,
    'message' => 'Payment verified and recorded',
    'payment_id' => $payment_id,
    'order_id' => $order_id,
    'donation' => $row
]);

if ($isSignatureValid) {
    header("Location: donate.php?status=success&payment_id=" . urlencode($razorpay_payment_id));
    exit();
} else {
    header("Location: donate.php?status=failed");
    exit();
}
